1. Description

This dataset includes HTML tables extracted from PDF sources and relevant
paragraphs, and references between them.
Pew and Academic datasets are available here.
For the Kong dataset, please refer to "Extracting references between text 
and charts via crowdsourcing" (Kong et al).
Please refer to "Facilitating Document Reading by Linking Text and Tables" 
(Kim et al.) for more information.

2. Structure

Pew Source (Original PDF files for Pew dataset)
Academic Sources (Origical PDF files for Academic dataset)
HTML Tables (HTML converted versions of the tables)
metadata.json (the title of the paper, captions and relevant paragraphs)
reference_data.json (References between text and tables)

3. JSON navigation

The data is structured: dataset name > paper name > table # > paragraph #

metadata.json
[DATASET NAME]
  [PAPER NAME]
    title (title of paper)
    tables
      [TABLE #]
        caption (caption of table)
        paragraphs
          [PARAGRAPH #]
            content (text content of paragraph)
            sentences (LIST of sentences)
              sentence_idx
              offset (offset from the beginning of paragraph)
              content (text content of sentence)

reference_data.json
[DATASET NAME]
  [PAPER NAME]
    tables
      [TABLE #]
        paragraphs
          [PARAGRAPH #]
            references (LIST of references)
              ref_cell (LIST of cells in the reference)
                row_idx
                col_idx
                content (text content of table cell)
              ref_text (LIST of text in the reference (the sentence))
                start_idx
                length
                content (text content of the text (the sentence))

4. Additional Notes

Due to unforeseen circumstances, we were unable to retrieve the exact
dataset used in the paper. This dataset closely matches what we used
to evaluate our pipeline, but the number of documents / tables / paragraphs
/ (sentence, table) pairs may differ slightly from what is reported in
the paper.